from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.fields.html5 import EmailField
from wtforms.validators import DataRequired

class formContacto(FlaskForm):

    nombre = StringField("Nombre del contacto")
    correo = EmailField("Correo electronico")
    mensaje = StringField("Mensaje")
    enviar =  SubmitField("Enviar")