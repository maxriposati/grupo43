from flask import Flask, render_template, request, flash
from db import get_db
from formulario import formContacto
import os

app = Flask(__name__)
app.secret_key = os.urandom( 24 )

@app.route('/', methods=['GET', 'POST'])

def contacto():
    form = formContacto()

    return render_template("contacto.html", titulo="Contactenos", form = form)

@app.route('/usuarios')
def usuarios():
    db = get_db()
    usuarios = db.execute(
        'SELECT id, Nombre, Usuario, Correo FROM usuario '
    ).fetchall()
    return render_template('usuarios.html', usuarios = usuarios)



@app.route( '/login', methods=('GET', 'POST') )
def login():
    try:
        if request.method == 'POST':
            
            username = request.form['username']
            password = request.form['password']
            
            if not username:
                error = 'Debes ingresar el usuario'
                flash( error )
                return render_template( 'login.html' )
            
            if not password:
                error = 'Contraseña requerida'
                flash( error )
        
            db = get_db()
            
            user = db.execute(
                    'SELECT * FROM usuario WHERE usuario=? and contrasena=? ', (username,password)
                    ).fetchone()
            
            if user is None:
                error = 'Usuario o contraseña inválidos'
                flash( error )
            else:
                error="usuario valido"
                flash( error )

        return render_template( 'login.html' )
    except:
        return render_template( 'login.html' )


if  __name__ == "__main__":

    os.environ['FLASK_ENV'] = 'development'
    app.run(debug=True)